module.exports = {
  mode: 'jit',
  purge: ["./src/**/*.html", "./src/**.{js,jsx,ts,tsx,vue}"],
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
