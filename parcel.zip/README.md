<h1 align="center">Parcel 2 + Tailwind CSS 3.3.0</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-3.3.0-blue.svg?cacheSeconds=2592000" />
  <a href="https://github.com/codypl/parcel-tailwind-starter/blob/main/LICENSE" target="_blank">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" />
  </a>
</p>

## Get Started
```
# Clone repo
git clone https://github.com/codypl/parcel-tailwind-starter.git
cd parcel-tailwind-starter

# Install dependencies
npm i

# Run dev server - available at http://localhost:1234
npm run dev

# Run production build
npm run build
```
